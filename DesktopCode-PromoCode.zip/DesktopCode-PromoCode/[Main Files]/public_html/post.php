<?php
session_start();
include 'config.php';
$id = (int) $_GET['id'];
if (empty($id)) {
    echo '<meta http-equiv="refresh" content="0; url=error.php">';
}

$runq = mysqli_query($connect, "SELECT * FROM `posts` WHERE id='$id'");
if (mysqli_num_rows($runq) == 0) {
    echo '<meta http-equiv="refresh" content="0; url=error.php">';
}
$row         = mysqli_fetch_assoc($runq);

?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title><?php echo $row['title']; ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Noto+Sans:400,700'><link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="modal-frame">
  <div class="modal">
		    <div class="modal-inset">
      			<div class="button close"><i class="fa fa-close"></i></div>
	<div class="coupon">
      <div class="modal-body">
				        <h1><br><?php echo $row['title']; ?>!</h1><br><br>
<h2><font color="green"><b><?php echo $row['title2']; ?>% OFF</font></b></h2><br><br>
        				<h2><p><?php echo $row['content']; ?></p></h2><br><br>
<h3><p>
<br>
Code:<p id="p1"><span class="promo"><?php echo $row['code']; ?></p></span>
<button class="fancy-btn2" onclick="copyToClipboard('#p1')">COPY CODE</button>
</p></h3>
<script src="https://kit.fontawesome.com/aa0bacc6a9.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
function copyToClipboard(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
</script>
<br><br>
        <green>Expires: <?php echo $row['date2']; ?></green>
      			</div>
    		</div>
  	</div>
</div>
</div>
<div class="modal-overlay"></div>


<button class="fancy-btn open">Click to view coupon!</button>
<!-- partial -->
  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>

</body>
</html>
