<?php
include "header.php";
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@5.9.55/css/materialdesignicons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<style>
@import url('https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Exo+2:wght@500&display=swap');
</style>
<style>
@import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree&display=swap');
</style>
<style>
@import url('https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@500&display=swap');
</style>
<style>
html *
{
font-family: 'Bai Jamjuree;
font-size: 14px;
}

.copyright { margin-top: 50px; font-size: 12px; text-transform: uppercase; }
.copyright a { text-decoration: none; padding: 5px;background: #c0392b; color: #000; }
.copyright a:hover { background: transparent; color: #c0392b; }

.copyright *
{
font-family: 'Exo 2'; !important;
text-transform: uppercase; 
font-size: 12px;
}
</style>

	<div class="col-md-9">
      <div>
        <ol class="breadcrumb">
          <li><a href="dashboard.php">Home</a></li>
          <li class="active">Dashboard</li>
        </ol>
      </div>

	  <div class="row">
        <div class="col-md-12 column">
            <div class="box">
  
              <div class="box-container-toggle">
                  <div class="box-content">
				  <ul class="shortcut-list">
							
<h2><center><br>Welcome to the <b>Admin Panel</b></h2>
<br><br><center><b>Version 1.0</b> <b> 10/07/2023 </b>-  First release of PromoCode. <br>
<b>Version 1.2</b> <b> 11/06/2024:</b> - The Coupons have been updated to Modals, and the Admin Panel has been changed.<br>

<br><br>

<br><br>Demo Promo Coupon:<br>
<br>

<a href='../post.php?id=75161' class='btn btn-primary' target='_blank'>Promo 1</a>   
<br>

<br>
<br>
<?php
$sql    = "SELECT * FROM settings";
$result = mysqli_query($connect, $sql);
while ($s = mysqli_fetch_assoc($result)) {
?>
<!-- Facebook -->
<a class='btn btn-primary' style='background-color: #3b5998;' href='<?php echo $s['facebook']; ?>' role='button'
  ><i class='fa fa-facebook'></i
></a>

<!-- Twitter -->
<a class='btn btn-primary' style='background-color: #55acee;' href='<?php echo $s['twitter']; ?>' role='button'
  ><i class='fa fa-twitter'></i
></a>

<!-- Youtube -->
<a class='btn btn-primary' style='background-color: #ed302f;' href='<?php echo $s['youtube']; ?>' role='button'
  ><i class='fa fa-youtube'></i
></a>
<br><br>
<?
}
?>
						</ul>
				  </div>
              </div>
            </div>
        </div>
      </div>
	  
	  <div class="row">

         
              </div>
            </div>
         </div>
      </div>
 
    </div>
  </div>

<?php
include "footer.php";
?>