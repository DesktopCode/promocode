  <footer class="footer">
      <div class="container">
   <p class="text-muted"><center>COPYRIGHT &copy; <?php
echo date("Y");
?> DESKTOP CODE. WWW.DESKTOPCODE.COM - ALL RIGHTS RESERVED</p>
      </div>
  </footer>
</div>

    <!-- Bootstrap --> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
    
    <!--DataTables-->
    <script src="assets/plugins/datatables/datatables.min.js"></script>

  </body>
</html>